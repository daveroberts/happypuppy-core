<?
require_once('dbobject.php');
require_once('inflector.php');
?>