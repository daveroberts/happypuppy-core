<?
namespace HappyPuppy;
class hasManyRelation
{
	var $name;
	var $sort_by;
	var $foreign_table;
	var $foreign_class;
	var $foreign_key;
	
	function __construct($name, $sort_by='', $foreign_table = '', $foreign_class = '', $foreign_key = '')
	{
		if ($foreign_table == ''){ $foreign_table = Inflector::remove_underscores($relation); }
		if ($class_name == ''){ $class_name = Inflector::remove_underscores($relation); }
		if ($foreign_key == ''){ $foreign_key = strtolower(get_class($this)).'_id'; }
		$this->name = $name;
		$this->sort_by = $sort_by;
		$this->foreign_table = $foreign_table;
		$this->foreign_class = $foreign_class;
		$this->foreign_key = $foreign_key;
	}
}

?>