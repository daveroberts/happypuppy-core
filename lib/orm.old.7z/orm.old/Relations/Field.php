<?

class Field
{

	var $name;
	var $type;

	function __construct()
	{
	}

}

?>