<?

namespace HappyPuppy;
require('hasManyRelation.php');
require_once('RelationCollection.php');

class HasManyRelations extends RelationCollection
{
	function __construct($dbobject)
	{
		parent::__construct($dbobject);
	}
	protected function build_relation($name, $cache_db_values = true)
	{
		$relation = $this->_relations[$name];
		$sort_by = $relation->sort_by;
		$foreign_table = $relation->foreign_table;
		$foreign_class = $relation->foreign_class;
		$foreign_key = $relation->foreign_key;
		$sql = "SELECT a.* FROM ".$foreign_table." a ";
		$sql .=" LEFT JOIN ".$this->_dbobject->tablename." b ON a.".$foreign_key.'=b.'.$this->_dbobject->pk." ";
		$pk_string = $this->_dbobject->pk;
		$sql .=" WHERE b.".$this->_dbobject->pk."='".$this->_dbobject->$pk_string."' ";
		if ($sort_by != "")
		{
			$sql .= " ORDER BY a.".$sort_by." ";
		}
		$db_results = DB::query($sql);
		$this->_db_values[$name] = array();
		foreach($db_results as $db_row)
		{
			$obj = new $foreign_class();
			$pk_string = $obj->pk;
			$obj->build($db_row);
			$this->_db_values[$name][$obj->$pk_string] = $obj;
		}
		if ($cache_db_values)
		{
			$this->_cached_values = $this->_db_values;
		}
	}
	public function save_new_ids($relation_name, $new_ids)
	{
		if (!$this->hasRelation($relation_name)){ throw new Exception("No relation named ".$relation_name); }
		if (!is_array($new_ids)){ throw new Exception($relation_name." must be set to an array"); }
		$relation = $this->_relations[$relation_name];
		// have the db values been loaded?
		if (!array_key_exists($relation_name, $this->_db_values))
		{
			$this->build_relation($relation_name, false);
		}
		$foreign_fk_col = $relation->foreign_key;
		// iterate over the db values
		foreach($this->_db_values[$relation_name] as $obj)
		{
			// get the objects primary key, is this an object we will need to update?
			$foreign_pk_col = $obj->pk;
			$foreign_pk_val = $obj->$foreign_pk_col;
			if (in_array($pk, $new_ids))
			{
				// we already have this one
				$key = array_search($foreign_pk_val, $new_ids);
				unset($new_ids[$key]);
			}
			else
			{
				// update the foreign key of this object to null
				$sql = "UPDATE ".$relation->foreign_table." SET ".$foreign_fk_col."=NULL WHERE ".$foreign_pk_col."=".$foreign_pk_val." LIMIT 1";
				$db_results = DB::query($sql);
			}
		}
		// Update the entries which where not already pointing here
		$gen_obj = new $relation->foreign_class();
		$foreign_pk_col = $gen_obj->pk;
		$this_pk_col = $this->_dbobject->pk;
		$this_pk_val = $this->_dbobject->$this_pk_col;
		foreach($new_ids as $new_id)
		{
			$sql = "UPDATE ".$relation->foreign_table." SET ".$foreign_fk_col."=".$this_pk_val." WHERE ".$foreign_pk_col."=".$new_id." LIMIT 1";
			$db_results = DB::query($sql);
		}
		//reload the new database and cached values
		$this->build_relation($relation_name, true);
		return true;
	}
	public function setRelation($relation_name, $value)
	{
		if (!like_array($value)){ throw new Exception($relation_name." can only be an array, even if it's one item"); }
		$this->_cached_values[$relation_name] = array();
		foreach($value as $obj)
		{
			$pk_col = $obj->pk;
			$pk_val = $obj->$pk_col;
			$this->_cached_values[$relation_name][$pk_val] = $obj;
		}
	}
}

?>