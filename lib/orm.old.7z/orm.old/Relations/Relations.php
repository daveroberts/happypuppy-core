<?php

namespace HappyPuppy;
require("hasManyRelations.php");
require("hasOneRelations.php");
require("habtmRelations.php");

class Relations
{
	private $_has_many;
	private $_has_one;
	private $_habtm;
	function __construct($dbobject)
	{
		$this->_has_many = new HasManyRelations($dbobject);
		$this->_has_one = new HasOneRelations($dbobject);
		$this->_habtm = new HabtmRelations($dbobject);
	}
	public function hasRelation($relation_name)
	{
		// iterate through all relation stores.  Return true if any return true
		if ($this->_has_many->hasRelation($relation_name)){ return true; }
		if ($this->_has_one->hasRelation($relation_name)){ return true; }
		if ($this->_habtm->hasRelation($relation_name)){ return true; }
		return false;
	}
	public function getRelationType($relation_name)
	{
		if ($this->_has_many->hasRelation($relation_name)){ return $this->_has_many->getRelationType($relation_name); }
		if ($this->_has_one->hasRelation($relation_name)){ return $this->_has_one->getRelationType($relation_name); }
		if ($this->_habtm->hasRelation($relation_name)){ return $this->_habtm->getRelationType($relation_name); }
		return null;
	}
	public function getRelationValues($relation_name)
	{
		if ($this->_has_many->hasRelation($relation_name)){ return $this->_has_many->getRelationValues($relation_name); }
		if ($this->_has_one->hasRelation($relation_name)){ return $this->_has_one->getRelationValues($relation_name); }
		if ($this->_habtm->hasRelation($relation_name)){ return $this->_habtm->getRelationValues($relation_name); }
		return null;
	}
	public function setRelation($relation_name, $new_value)
	{
		if ($this->_has_many->hasRelation($relation_name))
		{
			return $this->_has_many->setRelation($relation_name, $new_value);
		}
		if ($this->_has_one->hasRelation($relation_name))
		{
			return $this->_has_one->setRelation($relation_name, $new_value);
		}
		if ($this->_habtm->hasRelation($relation_name))
		{
			return $this->_habtm->setRelation($relation_name, $new_value);
		}
		return false;
	}
	public function addIntoRelation($relation_name, $key, $value, $fromDB = false)
	{
		if ($this->_has_many->hasRelation($relation_name))
		{
			return $this->_has_many->addIntoRelation($relation_name, $key, $value, $fromDB);
		}
		if ($this->_has_one->hasRelation($relation_name))
		{
			return $this->_has_one->addIntoRelation($relation_name, $key, $value, $fromDB);
		}
		if ($this->_habtm->hasRelation($relation_name))
		{
			return $this->_habtm->addIntoRelation($relation_name, $key, $value, $fromDB);
		}
		return false;
	}
	public function has_many(
		$relation_name,
		$sort_by='',
		$foreign_table = '',
		$foreign_class = '',
		$foreign_key = '')
	{
		$has_many_relation = new hasManyRelation($relation_name, $sort_by, $foreign_table, $foreign_class, $foreign_key);
		$this->_has_many->addRelation($has_many_relation);
	}
	public function has_one(
		$relation_name,
		$sort_by = '',
		$foreign_table = '',
		$foreign_class = '',
		$foreign_key = '')
	{
		$has_one_relation = new hasOneRelation($relation_name, $sort_by, $foreign_table, $foreign_class, $foreign_key);
		$this->_has_one->addRelation($has_one_relation);
	}
	public function habtm(
		$relation_name,
		$sort_by='',
		$link_table = '',
		$foreign_table = '',
		$foreign_class = '',
		$link_table_fk_here = '',
		$link_table_fk_foreigntable = '',
		$foreign_table_pk = '')
	{
		$habtm_relation = new habtmRelation($relation_name, $sort_by, $link_table, $foreign_table, $foreign_class, $link_table_fk_here, $link_table_fk_foreigntable, $foreign_table_pk);
		$this->_habtm->addRelation($habtm_relation);
	}
	public function save()
	{
		$result = $this->_has_many->save_all_relations();
		if (!$result){ return false; }
		$result = $this->_habtm->save_all_relations();
		if (!$result){ return false; }
		$result = $this->_has_one->save_all_relations();
		if (!$result){ return false; }
		return true;
	}
	public function destroy()
	{
		//TODO destroy relations
	}
}

?>