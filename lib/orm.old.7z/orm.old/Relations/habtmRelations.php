<?php

namespace HappyPuppy;
require('habtmRelation.php');
require_once('RelationCollection.php');

class HabtmRelations extends RelationCollection
{
	function __construct($dbobject)
	{
		parent::__construct($dbobject);
	}
	protected function build_relation($name, $cache_db_values = true)
	{
		$relation = $this->_relations[$name];
		$sort_by = $relation->sort_by;
		$link_table = $relation->link_table;
		$foreign_table = $relation->foreign_table;
		$foreign_class = $relation->foreign_class;
		$link_table_fk_here = $relation->link_table_fk_here;
		$link_table_fk_foreigntable = $relation->link_table_fk_foreigntable;
		$foreign_table_pk = $relation->foreign_table_pk;
		$sql = "SELECT f.* FROM ".$foreign_table." f ";
		$sql .=" LEFT JOIN ".$link_table." fp ON f.".$foreign_table_pk.'=fp.'.$link_table_fk_foreigntable." ";
		$sql .=" LEFT JOIN ".$this->_dbobject->tablename." p ON fp.".$link_table_fk_here.'=p.'.$this->_dbobject->pk." ";
		$pk_string = $this->_dbobject->pk;
		$sql .=" WHERE p.".$this->_dbobject->pk."='".$this->_dbobject->$pk_string."' ";
		if ($sort_by != "")
		{
			$sql .= " ORDER BY f.".$sort_by." ";
		}
		$db_results = DB::query($sql);
		$this->_db_values[$name] = array();
		foreach($db_results as $db_row)
		{
			$obj = new $foreign_class();
			$obj->build($db_row);
			$this->_db_values[$name][] = $obj;
		}
		if ($cache_db_values)
		{
			$this->_cached_values = $this->_db_values;
		}
	}
	public function save_new_ids($relation_name, $new_ids)
	{
		if (!$this->hasRelation($relation_name)){ throw new Exception("No relation named ".$relation_name); }
		if (!is_array($new_ids)){ throw new Exception($relation_name." must be set to an array"); }
		$relation = $this->_relations[$relation_name];
		// have the db values been loaded?
		if (!array_key_exists($relation_name, $this->_db_values))
		{
			$this->build_relation($relation_name, false);
		}
		$this_pk_col = $this->_dbobject->pk;
		$this_pk_val = $this->_dbobject->$this_pk_col;
		$link_here_col = $relation->link_table_fk_here;
		$link_foreign_col = $relation->link_table_fk_foreigntable;
		// iterate over the db values
		foreach($this->_db_values[$relation_name] as $obj)
		{
			// get the objects primary key, is this an object we will need to update?
			$foreign_pk_col = $obj->pk;
			$foreign_pk_val = $obj->$foreign_pk_col;
			if (in_array($foreign_pk_val, $new_ids))
			{
				// we already have this one
				$key = array_search($foreign_pk_val, $new_ids);
				unset($new_ids[$key]);
			}
			else
			{
				// delete the link between these two objects
				$sql = "DELETE FROM ".$relation->link_table." WHERE ";
				$sql .= $link_here_col."=".$this_pk_val." AND ".$link_foreign_col."=".$foreign_pk_val." LIMIT 1";
				$db_results = DB::query($sql);
			}
		}
		// Update the entries which where not already pointing here
		$gen_obj = new $relation->foreign_class();
		$foreign_pk_col = $gen_obj->pk;
		$this_pk_col = $this->_dbobject->pk;
		$this_pk_val = $this->_dbobject->$this_pk_col;
		foreach($new_ids as $new_id)
		{
			$sql = "INSERT INTO ".$relation->link_table." ";
			$sql .= "(".$link_here_col.", ".$link_foreign_col.") VALUES ";
			$sql .= "(".$this_pk_val.", ".$new_id.")";
			$db_results = DB::query($sql);
		}
		//reload the new database and cached values
		$this->build_relation($relation_name, true);
		return true;
	}
	public function setRelation($relation_name, $value)
	{
		if (!like_array($value)){ throw new Exception($relation_name." can only be an array, even if it's one item"); }
		$this->_cached_values[$relation_name] = array();
		foreach($value as $obj)
		{
			$pk_col = $obj->pk;
			$pk_val = $obj->$pk_col;
			$this->_cached_values[$relation_name][$pk_val] = $obj;
		}
	}
}

?>