<?

namespace HappyPuppy;
abstract class RelationCollection
{
	protected $_dbobject;
	protected $_relations;
	protected $_db_values; //
	protected $_cached_values; // 
	function __construct($dbobject)
	{
		$this->_dbobject = $dbobject;
		$this->_relations = array();
		$this->_db_values = array();
		$this->_cached_values = array();
	}
	public function addRelation($relation)
	{
		$this->_relations[$relation->name] = $relation;
	}
	public function hasRelation($relation_name)
	{
		return array_key_exists($relation_name, $this->_relations);
	}
	public function getRelationType($relation_name)
	{
		if (array_key_exists($relation_name, $this->_relations))
		{
			return $this->_relations[$relation_name];
		}
		return null;
	}
	public function getRelationValues($relation_name)
	{
		if (!array_key_exists($relation_name, $this->_cached_values))
		{
			$this->build_relation($relation_name);
		}
		return $this->_cached_values[$relation_name];
	}
	public function save_all_relations()
	{
		foreach($this->_relations as $relation_name=>$relation)
		{
			$result = $this->save($relation_name);
			if (!$result){ return false; }
		}
		return true;
	}
	// takes cached values and turns them into DB values
	public function save($relation_name)
	{
		if (!$this->hasRelation($relation_name)){ return false; }
		$new_ids = array();
		foreach($this->_cached_values as $key=>$val)
		{
			$new_ids[] = $key;
		}
		return $this->save_new_ids($relation_name, $new_ids);
	}
	// for the array based relationships only
	public function addIntoRelation($relation_name, $key, $value, $fromDB = false)
	{
		if ($fromDB) { $this->_db_values[$key] = $value; }
		$this->_cached_values[$relation_name][$key] = $value;
	}
	// just updates association of IDs
	public abstract function save_new_ids($relation_name, $new_ids);
	public abstract function setRelation($relation_name, $value);
	protected abstract function build_relation($relation_name, $cache_db_values = true);

}

?>