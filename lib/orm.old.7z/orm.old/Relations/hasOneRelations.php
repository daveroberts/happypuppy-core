<?php

namespace HappyPuppy;
require('hasOneRelation.php');
require_once('RelationCollection.php');

class HasOneRelations extends RelationCollection
{
	function __construct($dbobject)
	{
		parent::__construct($dbobject);
	}
	public function build_relation($name, $cache_db_values = true)
	{
		$relation = $this->_relations[$name];
		$sort_by = $relation->sort_by;
		$foreign_table = $relation->foreign_table;
		$foreign_class = $relation->foreign_class;
		$foreign_key = $relation->foreign_key;
		$obj = new $foreign_class();
		$sql = "SELECT a.* FROM ".$foreign_table." a ";
		$pk_string = $this->_dbobject->pk;
		$pk_foreign = $obj->pk;
		$sql .=" WHERE a.".$pk_foreign."='".$this->_dbobject->$foreign_key."' ";
		if ($sort_by != "")
		{
			$sql .= " ORDER BY a.".$sort_by." ";
		}
		$db_results = DB::query($sql);
		$this->_db_values[$name] = null;
		if (count($db_results) == 1)
		{
			$obj->build($db_results[0]);
			$this->_db_values[$name] = $obj;
		}
		if ($cache_db_values)
		{
			$this->_cached_values = $this->_db_values;
		}
	}
	public function save_new_ids($relation_name, $new_ids)
	{
		if (!$this->hasRelation($relation_name)){ throw new Exception("No relation named ".$relation_name); }
		if (is_array($new_ids)){ throw new Exception("Can't set ".$relation_name." to an array"); }
		$relation = $this->_relations[$relation_name];
		$foreign_table = $relation->foreign_table;
		$foreign_class = $relation->foreign_class;
		$foreign_key = $relation->foreign_key;
		// have the db values been loaded?
		if (!array_key_exists($relation_name, $this->_db_values))
		{
			$this->build_relation($relation_name, false);
		}
		$obj = $this->_db_values[$relation_name];
		if ($obj != null && $obj->$foreign_key == $new_ids)
		{
			return; // already set to this ID, nothing to do here
		}
		$pk_col = $this->_dbobject->pk;
		$pk_val = $this->_dbobject->$pk_col;
		// remove old association
		$sql = "UPDATE ".$this->_dbobject->table." ";
		$sql .= "SET ".$foreign_key."=".$new_ids." ";
		$sql .= "WHERE ".$pk_col."=".$pk_val." ";
		$sql .= "LIMIT 1";
		$db_results = DB::query($sql);
		//reload the new database and cached values
		$this->build_relation($relation_name, true);
		return true;
	}
	public function setRelation($relation_name, $value)
	{
		if (like_array($value)){ throw new Exception($relation_name." can't be set to an array"); }
		$this->_cached_values[$relation_name] = $value;
	}

}

?>