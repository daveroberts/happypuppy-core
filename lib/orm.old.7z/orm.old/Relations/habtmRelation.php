<?

namespace HappyPuppy;
class habtmRelation
{
	var $name;
	var $sort_by;
	var $link_table;
	var $foreign_table;
	var $foreign_class;
	var $link_table_fk_here;
	var $link_table_fk_foreigntable;
	var $foreign_table_pk;
	
	function __construct($name, $sort_by='', $link_table = '', $foreign_table = '', $foreign_class = '', $link_table_fk_here = '', $link_table_fk_foreigntable = '', $foreign_table_pk = '')
	{
		$this->name = $name;
		$this->sort_by = $sort_by;
		$this->link_table = $link_table;
		$this->foreign_table = $foreign_table;
		$this->foreign_class = $foreign_class;
		$this->link_table_fk_here = $link_table_fk_here;
		$this->link_table_fk_foreigntable = $link_table_fk_foreigntable;
		$this->foreign_table_pk = $foreign_table_pk;
	}
}

?>