<?

namespace HappyPuppy;
class Fields
{
	private $_dbobject;
	private $_pk;
	private $_field_values = array();  // just use getters and setters

	function __construct($dbobject)
	{
		$this->_dbobject = $dbobject;
	}
	public function getPK()
	{
		if (!isset($this->_pk))
		{
			$field_structure = DB::get_field_structure($this->_dbobject->tablename);
			$this->_pk = $field_structure["pk"];
		}
		return $this->_pk;
	}
	public function hasField($field_name)
	{
		$field_structure = DB::get_field_structure($this->_dbobject->tablename);
		return array_key_exists($field_name, $field_structure["fields"]);
	}
	public function getField($name)
	{
		if ($this->hasField($name))
		{
			return $this->_field_values[$name];
		}
		else
		{
			global $__not_found;
			return $__not_found;
		}
	}
	public function setField($name, $value, $mark_dirty = true)
	{
		//TODO fill me in
		$this->_field_values[$name] = $value;
	}
	private function fieldNames()
	{
		$field_structure = DB::get_field_structure($this->_dbobject->tablename);
		return array_keys($field_structure["fields"]);
	}
	public function build($arr)
	{
		foreach($this->fieldNames() as $field)
		{
			$this->setField($field, $arr[$field]);
		}
	}
	public function save()
	{
		if ($this->getField($this->getPK()) == null)
		{
			return $this->insert();
		}
		else
		{
			return $this->update();
		}
	}
	private function insert()
	{
		$sql = "INSERT INTO ".$this->_dbobject->tablename." (";
		foreach($this->fieldNames() as $field)
		{
			if ($field == $this->getPK()){ continue; }
			$sql .= $field.", ";
		}
		$sql = rtrim($sql, ", ");
		$sql .= ") VALUES (";
		foreach($this->fieldNames() as $field)
		{
			if ($field == $this->getPK()){ continue; }
			$sql .= "'".addslashes($this->getField($field))."', ";
		}
		$sql = rtrim($sql, ", ");
		$sql .= ")";
		$result = DB::exec($sql);
		if ($result)
		{
			$id = DB::lastInsertId();
			$this->setField($this->getPK(), $id, false);
		}
		return $result;
	}
	private function update()
	{
		$sql = "UPDATE ".$this->_dbobject->tablename." SET ";
		foreach($this->field_names() as $field)
		{
			if ($field == $this->getPK()){ continue; }
			$sql .= $field."='".addslashes($this->getField($field))."', ";
		}
		$sql = rtrim($sql, ", ");
		$sql .= " WHERE ".$this->getPK()."='".$this->getField($this->getpk())."'";
		$result = DB::exec($sql);
		return $result;
	}

	public function destroy()
	{
		$sql = "DELETE FROM ".$this->_tablename." WHERE ".$this->getPK()."='".addslashes($this->getField($this->getPK()))."' LIMIT 1";
		return DB::query($sql);
	}
}

?>