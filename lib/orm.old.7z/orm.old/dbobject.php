<?
namespace HappyPuppy;
require("Relations/Fields.php");
require("Relations/Relations.php");
require("dbobjectCollection.php");
require("sqlFinder.php");

global $__not_found; // returned when a field is not found
$__not_found = "__NOT_FOUND__";
//TODO separate cached fields versus uncached fields
//TODO dbobject groups as arrays
//TODO changing relationships
//TODO saving relationships
//TODO static find methods (requires php5.3)
//TODO better select box
//TODO check the form inputs for habtm again
//TODO form populating (reloading) on invalid data
//TODO form validation
//TODO If you have a person, how to create a bank account under that person
//FIXME return empty array if none in a many association, not null
abstract class dbobject
{
	private $_fields; // cache of values for fields
	private $_relations;
	private $_sqlFinder;
	private $_tablename = ''; // set with constructor, get using property
	private $_description; // set with method, get with method

	function __construct($tablename)
	{
		$this->_tablename = $tablename;
		if($this->_tablename == "")
		{
			$this->_tablename = Inflector::plural(get_class($this));
		}
		$this->_fields = new Fields($this);
		$this->_relations = new Relations($this);
		$this->_sqlFinder = new sqlFinder($this);
	}
	public function setDescription($value)
	{
		$this->_description = $value;
	}
	public function getDescription()
	{
		return $this->_description;
	}
	public function hasField($field_name)
	{
		return $this->_fields->hasField($field_name);
	}
	public function getRelationType($relation_name)
	{
		return $this->_relations->getRelationType($relation_name);
	}
	public function getRelation($relation_name)
	{
		return $this->_relations->getRelation($relation_name);
	}
	public function hasRelation($relation_name)
	{
		return $this->_relations->hasRelation($relation_name);
	}
	private function setRelation($relation_name, $new_value)
	{
		return $this->_relations->setRelation($relation_name, $new_value);
	}
	public function addIntoRelation($relation_name, $key, $value, $fromDB = false)
	{
		return $this->_relations->addIntoRelation($relation_name, $key, $value, $fromDB);
	}
	protected function has_many(
		$relation_name,
		$sort_by='',
		$foreign_table = '',
		$foreign_class = '',
		$foreign_key = '')
	{
		$this->_relations->has_many($relation_name, $sort_by, $foreign_table, $foreign_class, $foreign_key);
	}
	protected function has_one(
		$relation_name,
		$sort_by = '',
		$foreign_table = '',
		$foreign_class = '',
		$foreign_key = '')
	{
		$this->_relations->has_one($relation_name, $sort_by, $foreign_table, $foreign_class, $foreign_key);
	}
	protected function habtm(
		$relation_name,
		$sort_by='',
		$link_table = '',
		$foreign_table = '',
		$foreign_class = '',
		$link_table_fk_here = '',
		$link_table_fk_foreigntable = '',
		$foreign_table_pk = '')
	{
		$this->_relations->habtm($relation_name, $sort_by, $link_table, $foreign_table, $foreign_class, $link_table_fk_here, $link_table_fk_foreigntable, $foreign_table_pk);
	}
	function __get($name)
	{
		if ($name == "tablename")
		{
			return $this->_tablename;
		}
		if ($name == "modelname")
		{
			return get_class($this);
		}
		if ($name == "pk")
		{
			return $this->_fields->getPK();
		}
		if ($this->_fields->hasField($name))
		{
			return $this->_fields->getField($name);
		}
		if ($this->_relations->hasRelation($name))
		{
			return $this->_relations->getRelationValues($name);
		}
		return null;
	}
	function __set($name, $value)
	{
		if ($this->_fields->hasField($name))
		{
			$this->_fields->setField($name, $value);
			return;
		}
		if ($this->hasRelation($name))
		{
			$this->_relations->setRelation($name, $value);
			return;
		}
		throw new Exception($name." is not a field or relation");
	}
	public function build_all($db_results)
	{
		$obj_array = array();
		$klass = get_class($this);
		$pk_col = $this->pk;
		foreach($db_results as $db_row)
		{
			$obj = new $klass();
			$obj->build($db_row);
			$obj_array[$obj->$pk_col] = $obj;
		}
		return $obj_array;
	}
	public function build($arr)
	{
		$this->_fields->build($arr);
	}
	public function find($args)
	{
		return $this->_sqlFinder->find($args);
	}
	public function get($pk_id)
	{
		$sql = "SELECT * FROM ".$this->tablename." t WHERE t.".$this->pk."=".addslashes($pk_id);
		$db_results = DB::query($sql);
		if (count($db_results) == 0){ return null; }
		$this->build($db_results[0]);
		return $this;
	}
	public static function get($pk_id)
	{
		print("This is a static method");
		return 666;
	}
	public function getfirst()
	{
		$sql = "SELECT TOP 1 * FROM ".$this->tablename;
		$db_results = DB::query($sql);
		if (count($db_results) == 0){ return null; }
		$this->build($db_results[0]);
		return $this;
	}
	public function getAll($sort_by = '')
	{
		$sql = "SELECT * FROM ".$this->tablename.' ';
		if ($sort_by != "")
		{
			$sql .= " ORDER BY ".$sort_by." ";
		}
		$db_results = DB::query($sql);
		$obj_array = array();
		foreach($db_results as $db_row)
		{
			$klass = get_class($this);
			$obj = new $klass();
			$obj->build($db_row);
			$obj_array[] = $obj;
		}
		return $obj_array;
	}
	public function save()
	{
		$result = $this->_fields->save();
		if (!$result){ return false; }
		$result = $this->_relations->save();
		if (!$result){ return false; }
		return true;
	}
	public function destroy()
	{
		$result = $this->_fields->destroy();
		if (!result){ return false; }
		$result = $this->_relations->destroy();
		if (!result){ return false; }
		return true;
	}
	public function __call($name, $args)
	{
		if (substr($name, 0, 8) == "find_by_")
		{
			$name = substr($name, 8);
			return $this->find_by($name, $args);
			// TODO find by methods
		}
		if (substr($name, 0, 4) == "get_")
		{
			$name = substr($name, 4);
			if ($this->hasRelation($name))
			{
				return $this->_relations->getRelationValues($name);
			}
		}
		throw new \Exception($name." is not a valid method");
	}
}
?>